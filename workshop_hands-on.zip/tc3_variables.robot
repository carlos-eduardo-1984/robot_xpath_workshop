*** Settings ***
Documentation    Workshop Robot Framework - TC3 Variables Example

Library      Browser

*** Variables ***
${URL}    https://carlos-eduardo-1984.github.io/robot_xpath_workshop/

${FIRST_NAME_INPUT}          //input[@id="firstName"]
${EMAIL_INPUT}               //input[@id="emailAddress"]
${COUNTRY_SELECT}            //select[@id="countrySelect"]
${YEARS_EXPERIENCE_INPUT}    //input[@id="experienceYears"]
${EMPLOYEE_ID_INPUT}         //input[@id="employeeId"]
${PHONE_INPUT}               //input[@id="phoneNumber"]
${BIRTH_DATE_INPUT}          //input[@id="birthDate"]
${CONTACT_SELECT}            //select[@id="preferredContact"]
${BIO_TEXTAREA}              //textarea[@id="bioText"]
${MOTIVATION_TEXTAREA}       //textarea[@id="motivationText"]
${ADVANCED_LEVEL_RADIO}      //input[@id="lvlAdvanced"]

${STREET_INPUT}              //input[@name="street_name"]
${STREET_NUMBER_INPUT}       //input[@name="street_number"]
${ZIP_CODE_INPUT}            //input[@name='zip_code']
${CITY_INPUT}                //input[@name='city_name']
${DEPARTMENT_SELECT}         //select[@name="department"]
${WORK_SHIFT_SELECT}         //select[@name="work_shift"]
${MANAGER_INPUT}             //input[@name="manager_name"]
${OFFICE_LOCATION_INPUT}     //input[@name="office_location"]

${MAIN_BROWSER_SELECT}       //select[@id="mainBrowser"]
${OS_CHOICE_SELECT}          //select[@id="osChoice"]
${ROBOT_LEVEL_SELECT}        //select[@id="robotLevel"]
${XPATH_LEVEL_SELECT}        //select[@id="xpathLevel"]

${SUBMIT_BUTTON}             //button[@id="submitBtn"]


*** Test Cases ***
Workshop TestCase 3
    [Documentation]    Reusable keyword example with XPath locators extracted to a variables file

    New Browser    browser=chromium    headless=${False}    args=["--ignore-certificate-errors"]
    New Context    ignoreHTTPSErrors=${True}
    New Page    ${URL}
    Form Fill With Variables    name=Noah    email=noah.keller@swisspost.ch    country=ch    years_experience=6    employee_id=CH-005678
    ...                         phone=+41 76 555 11 22    birth=18.07.1990    contact=phone
    ...                         bio=Test automation consultant    motivation=Learn reusable locators
    ...                         address_street=Seestrasse    address_number=27    address_zip=6003    address_city=Lucerne
    ...                         department=operations    shift=afternoon    manager=Laura Frei    location=Lucerne Center
    ...                         browser=firefox    os=linux    rf_experience=intermediate    xpath_experience=advanced
    Go To    ${URL}
    Form Fill With Variables    name=Sofia    email=sofia.martins@swisspost.ch    country=pt    years_experience=9    employee_id=PT-002468
    ...                         phone=+351 912 345 678    birth=09.02.1986    contact=teams
    ...                         bio=QA coach    motivation=Show maintainable Robot Framework patterns
    ...                         address_street=Avenida da Liberdade    address_number=150    address_zip=1250-146    address_city=Lisbon
    ...                         department=it    shift=morning    manager=Ricardo Alves    location=Lisbon Office
    ...                         browser=edge    os=windows    rf_experience=advanced    xpath_experience=intermediate


*** Keywords ***
Form Fill With Variables
    [Arguments]    ${name}    ${email}    ${country}    ${years_experience}    ${employee_id}
    ...            ${phone}    ${birth}    ${contact}
    ...            ${bio}    ${motivation}
    ...            ${address_street}    ${address_number}    ${address_zip}    ${address_city}
    ...            ${department}    ${shift}    ${manager}    ${location}
    ...            ${browser}    ${os}    ${rf_experience}    ${xpath_experience}

    Type Text    ${FIRST_NAME_INPUT}    ${name}
    Type Text    ${EMAIL_INPUT}    ${email}
    Select Options By    ${COUNTRY_SELECT}    value    ${country}
    Type Text    ${YEARS_EXPERIENCE_INPUT}    ${years_experience}
    Type Text    ${EMPLOYEE_ID_INPUT}    ${employee_id}
    Type Text    ${PHONE_INPUT}    ${phone}
    Type Text    ${BIRTH_DATE_INPUT}    ${birth}
    Select Options By    ${CONTACT_SELECT}    value    ${contact}
    Type Text    ${BIO_TEXTAREA}    ${bio}
    Type Text    ${MOTIVATION_TEXTAREA}    ${motivation}
    Click    ${ADVANCED_LEVEL_RADIO}

    Type Text    ${STREET_INPUT}    ${address_street}
    Type Text    ${STREET_NUMBER_INPUT}    ${address_number}
    Type Text    ${ZIP_CODE_INPUT}    ${address_zip}
    Type Text    ${CITY_INPUT}    ${address_city}
    Select Options By    ${DEPARTMENT_SELECT}    value    ${department}
    Select Options By    ${WORK_SHIFT_SELECT}    value    ${shift}
    Type Text    ${MANAGER_INPUT}    ${manager}
    Type Text    ${OFFICE_LOCATION_INPUT}    ${location}

    Select Options By    ${MAIN_BROWSER_SELECT}    value    ${browser}
    Select Options By    ${OS_CHOICE_SELECT}    value    ${os}
    Select Options By    ${ROBOT_LEVEL_SELECT}    value    ${rf_experience}
    Select Options By    ${XPATH_LEVEL_SELECT}    value    ${xpath_experience}

    Click    ${SUBMIT_BUTTON}
    Wait For Elements State    //p[@id="resultMessage" and text()="Form submitted for ${name}!"]    visible
