@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "PY_VERSION=3.12.2"
set "PY_DIR=%LocalAppData%\Programs\Python\Python312"
set "PY_EXE=%PY_DIR%\python.exe"
set "PY_INSTALLER=%TEMP%\python-%PY_VERSION%-amd64.exe"

py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if not errorlevel 1 goto :run_launcher

python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if not errorlevel 1 goto :run_python

if not exist "%PY_EXE%" goto :download_python
"%PY_EXE%" -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if not errorlevel 1 goto :run_local

:download_python

echo Python 3.10+ was not found. Downloading Python %PY_VERSION% for this machine...
curl --fail --location -o "%PY_INSTALLER%" "https://www.python.org/ftp/python/%PY_VERSION%/python-%PY_VERSION%-amd64.exe"
if errorlevel 1 goto :error

if not exist "%PY_INSTALLER%" (
echo ERROR: Python installer download failed.
goto :error
)

echo Installing Python to %PY_DIR%...
start /wait "" "%PY_INSTALLER%" /quiet InstallAllUsers=0 PrependPath=0 Include_launcher=1 Include_pip=1 TargetDir="%PY_DIR%" /log "%TEMP%\workshop_python_install.log"
if "%ERRORLEVEL%"=="3010" goto :validate_python
if errorlevel 1 goto :error

:validate_python
if not exist "%PY_EXE%" (
echo ERROR: Python was not installed to %PY_DIR%.
goto :error
)

"%PY_EXE%" -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"
if errorlevel 1 goto :error

:run_local
"%PY_EXE%" "%SCRIPT_DIR%setup_workshop.py" %*
exit /b %ERRORLEVEL%

:run_launcher
py -3 "%SCRIPT_DIR%setup_workshop.py" %*
exit /b %ERRORLEVEL%

:run_python
python "%SCRIPT_DIR%setup_workshop.py" %*
exit /b %ERRORLEVEL%

:error
echo.
echo INSTALL FAILED
pause
exit /b 1
