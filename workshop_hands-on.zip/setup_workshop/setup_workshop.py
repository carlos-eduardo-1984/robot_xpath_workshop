#!/usr/bin/env python3
import argparse
import os
import platform
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV_DIR = ROOT / ".venv"
REQUIREMENTS = ROOT / "requirements.txt"


def log(message: str) -> None:
    print(f"[setup_workshop] {message}")


def run(command, cwd=None, env=None, check=True, capture_output=False):
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    result = subprocess.run(
        command, cwd=cwd, env=merged_env, text=True, capture_output=capture_output
    )
    if check and result.returncode != 0:
        raise RuntimeError(f"Command failed with exit code {result.returncode}: {' '.join(command)}")
    return result


def find_executable(*names):
    for name in names:
        resolved = shutil.which(name)
        if resolved:
            return resolved
    return None


def system_name():
    return platform.system().lower()


def python_version_tuple(command):
    result = run(command + ["-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')"], check=False, capture_output=True)
    if result.returncode != 0:
        return None
    version = result.stdout.strip()
    try:
        return tuple(int(part) for part in version.split("."))
    except ValueError:
        return None


def find_python():
    if sys.version_info >= (3, 10):
        return [sys.executable]

    candidates = []
    if system_name() == "windows":
        candidates.extend(["py", "python", "python3"])
    else:
        candidates.extend(["python3", "python", "py"])

    for candidate in candidates:
        exe = find_executable(candidate)
        if not exe:
            continue
        if candidate == "py":
            for version in ("3.12", "3.11", "3.10", "3"):
                command = [exe, f"-{version}"]
                detected_version = python_version_tuple(command)
                if detected_version is not None and detected_version >= (3, 10, 0):
                    return command
            continue
        version = python_version_tuple([exe])
        if version is not None and version >= (3, 10, 0):
            return [exe]
    return None


def ensure_python():
    py = find_python()
    if py:
        log(f"Using Python: {subprocess.list2cmdline(py)}")
        return py

    if system_name() == "windows":
        if find_executable("winget"):
            log("Python not found. Installing Python 3.12 via winget...")
            run(["winget", "install", "--id", "Python.Python.3.12", "-e", "--source", "winget"], check=True)
            return "py -3.12"
        if find_executable("choco"):
            log("Python not found. Installing Python 3.12 via Chocolatey...")
            run(["choco", "install", "python", "--version=3.12.2", "-y"], check=True)
            return "py -3.12"
        raise RuntimeError("Python 3.10+ is required, and no supported installer was found on Windows.")

    if system_name() == "darwin":
        if find_executable("brew"):
            log("Python not found. Installing Python 3.12 via Homebrew...")
            run(["brew", "install", "python@3.12"], check=True)
            return find_executable("python3") or "python3"
        raise RuntimeError("Python 3.10+ is required. Install it with Homebrew: brew install python@3.12")

    if find_executable("apt-get"):
        log("Python not found. Installing Python 3.12 via apt-get...")
        run(["sudo", "apt-get", "update"], check=False)
        run(["sudo", "apt-get", "install", "-y", "python3.12", "python3.12-venv", "python3-pip"], check=True)
        return find_executable("python3.12") or find_executable("python3") or "python3"

    if find_executable("dnf"):
        log("Python not found. Installing Python 3.12 via dnf...")
        run(["sudo", "dnf", "install", "-y", "python3.12", "python3.12-devel", "python3-pip"], check=True)
        return find_executable("python3.12") or find_executable("python3") or "python3"

    if find_executable("yum"):
        log("Python not found. Installing Python 3.12 via yum...")
        run(["sudo", "yum", "install", "-y", "python3.12", "python3.12-devel", "python3-pip"], check=True)
        return find_executable("python3.12") or find_executable("python3") or "python3"

    if find_executable("pacman"):
        log("Python not found. Installing Python 3.12 via pacman...")
        run(["sudo", "pacman", "-Syu", "--noconfirm", "python", "python-pip"], check=True)
        return find_executable("python") or "python"

    raise RuntimeError("Python 3.10+ is required. Please install it and re-run this script.")


def ensure_node():
    node = find_executable("node")
    if node:
        version = run([node, "--version"], check=False, capture_output=True)
        if version.returncode == 0:
            value = version.stdout.strip()
            match = re.fullmatch(r"v(\d+)\.(\d+)\.(\d+)", value)
            if match is None:
                raise RuntimeError(f"Unexpected Node.js version output: {value!r}")
            if int(match.group(1)) < 20:
                raise RuntimeError(f"Node.js 20+ is required; found {value}.")
            log(f"Using Node: {value}")
            return node

    if system_name() == "windows":
        if find_executable("winget"):
            log("Node.js not found. Installing LTS via winget...")
            run(["winget", "install", "--id", "OpenJS.NodeJS.LTS", "-e", "--source", "winget"], check=True)
            return find_executable("node") or "node"
        if find_executable("choco"):
            log("Node.js not found. Installing LTS via Chocolatey...")
            run(["choco", "install", "nodejs-lts", "-y"], check=True)
            return find_executable("node") or "node"
        raise RuntimeError("Node.js is required. Install Node LTS and rerun this script.")

    if system_name() == "darwin":
        if find_executable("brew"):
            log("Node.js not found. Installing LTS via Homebrew...")
            run(["brew", "install", "node"], check=True)
            return find_executable("node") or "node"
        raise RuntimeError("Node.js is required. Install it with Homebrew: brew install node")

    if find_executable("apt-get"):
        log("Node.js not found. Installing via apt-get...")
        run(["sudo", "apt-get", "update"], check=False)
        run(["sudo", "apt-get", "install", "-y", "nodejs", "npm"], check=True)
        return find_executable("node") or "node"

    if find_executable("dnf"):
        log("Node.js not found. Installing via dnf...")
        run(["sudo", "dnf", "install", "-y", "nodejs", "npm"], check=True)
        return find_executable("node") or "node"

    if find_executable("yum"):
        log("Node.js not found. Installing via yum...")
        run(["sudo", "yum", "install", "-y", "nodejs", "npm"], check=True)
        return find_executable("node") or "node"

    if find_executable("pacman"):
        log("Node.js not found. Installing via pacman...")
        run(["sudo", "pacman", "-Syu", "--noconfirm", "nodejs", "npm"], check=True)
        return find_executable("node") or "node"

    raise RuntimeError("Node.js is required. Please install Node LTS and rerun this script.")


def ensure_pip(venv_python):
    result = run([str(venv_python), "-m", "pip", "--version"], check=False)
    if result.returncode == 0:
        return
    log("pip was not available in the virtual environment. Bootstrapping it...")
    run([str(venv_python), "-m", "ensurepip", "--upgrade"], check=True)


def create_venv(base_python_cmd, venv_dir):
    if venv_dir.exists():
        log(f"Reusing existing virtual environment: {venv_dir}")
    else:
        log(f"Creating virtual environment at: {venv_dir}")
        run(base_python_cmd + ["-m", "venv", str(venv_dir)], check=True)

    venv_python = venv_dir / ("Scripts" if system_name() == "windows" else "bin")
    venv_python /= "python.exe" if system_name() == "windows" else "python"
    if not venv_python.is_file():
        raise RuntimeError(f"Virtual environment Python is missing: {venv_python}")
    run([str(venv_python), "-c", "import sys; sys.exit(0 if sys.prefix != sys.base_prefix else 1)"])
    return venv_python


def install_requirements(venv_python):
    ensure_pip(venv_python)
    log("Upgrading pip in the virtual environment...")
    run([str(venv_python), "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"], check=True)
    log("Installing workshop dependencies...")
    run([str(venv_python), "-m", "pip", "install", "-r", str(REQUIREMENTS)], check=True)


def rfbrowser_init(venv_dir):
    venv_bin = venv_dir / ("Scripts" if system_name() == "windows" else "bin")
    rfbrowser = venv_bin / ("rfbrowser.exe" if system_name() == "windows" else "rfbrowser")
    if not rfbrowser.exists():
        raise RuntimeError(f"rfbrowser executable not found at {rfbrowser}")
    log("Initialising Robot Framework Browser...")
    run([str(rfbrowser), "init"], check=True)


def print_activation_instructions():
    if system_name() == "windows":
        print("\nActivate the environment:")
        print("  .\\.venv\\Scripts\\activate")
    else:
        print("\nActivate the environment:")
        print("  source .venv/bin/activate")
    print("Then run: python -m robot --version")


def parse_args():
    parser = argparse.ArgumentParser(description="Set up the Robot Framework workshop environment in a local virtual environment.")
    parser.add_argument("--python", help="Explicit Python executable to use (for example: python3.12 or C:/Python312/python.exe)")
    parser.add_argument("--venv-path", default=str(VENV_DIR), help="Custom path for the virtual environment")
    parser.add_argument("--skip-browser-init", action="store_true", help="Skip running rfbrowser init")
    return parser.parse_args()


def main():
    args = parse_args()

    base_python = args.python or ensure_python()
    venv_dir = Path(args.venv_path).resolve()

    if not base_python:
        raise RuntimeError("Could not find a suitable Python interpreter.")

    # Normalise explicit Python values such as "py -3.12" or a full path.
    if isinstance(base_python, list):
        python_cmd = base_python
    elif base_python.startswith("py "):
        python_cmd = base_python.split()
    else:
        python_cmd = [base_python]

    version = python_version_tuple(python_cmd)
    if version is None or version < (3, 10, 0):
        raise RuntimeError("The selected interpreter must be Python 3.10+.")
    ensure_node()
    venv_python = create_venv(python_cmd, venv_dir)
    install_requirements(venv_python)

    if not args.skip_browser_init:
        rfbrowser_init(venv_dir)

    log("Workshop environment is ready.")
    print_activation_instructions()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except (RuntimeError, OSError) as exc:
        log(f"ERROR: {exc}")
        raise SystemExit(1)
