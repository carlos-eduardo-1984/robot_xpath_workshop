*** Settings ***
Documentation    Workshop Robot Framework - TC1 Basic Example

Library      Browser

*** Variables ***
${URL}    https://carlos-eduardo-1984.github.io/robot_xpath_workshop/


*** Test Cases ***
Workshop Structure
    [Documentation]    Basic structure with all steps written directly in the test case
