*** Settings ***
Documentation    Workshop Robot Framework - TC1 Basic Example

Library      Browser

*** Variables ***
${URL}    https://carlos-eduardo-1984.github.io/robot_xpath_workshop/


*** Test Cases ***
Workshop TestCase 1
    [Documentation]    Basic example with all steps written directly in the test case

    New Browser    browser=chromium    headless=${False}    args=["--ignore-certificate-errors"]
    New Context    ignoreHTTPSErrors=${True}
    New Page    ${URL}
    Type Text    id=firstName    John
    Type Text    id=emailAddress    john@swisspost.ch
    Select Options By    id=countrySelect    value    pt
    Type Text    id=experienceYears    4
    Type Text    id=employeeId    CH-000999
    Type Text    id=phoneNumber    +41 79 000 00 00
    Type Text    id=birthDate    01.01.1972
    Select Options By    id=preferredContact    value    teams
    Type Text    id=bioText    Small introduction
    Type Text    id=motivationText    Learn
    Click    id=lvlAdvanced
    Type Text    xpath=//input[@name="street_name"]    My Street
    Type Text    xpath=//input[@name="street_number"]    1
    Type Text    xpath=//input[@name='zip_code']     001
    Type Text    xpath=//input[@name='city_name']    The City
    Select Options By    xpath=//select[@name="department"]    value    operations
    Select Options By    //select[@name="work_shift"]    value    night
    Type Text    //input[@name="manager_name"]    Jane Doe
    Type Text    //input[@name="office_location"]    The City

    Select Options By    //select[@id="mainBrowser"]    value    chrome
    Select Options By    //select[@id="osChoice"]    value    windows
    Select Options By    //select[@id="robotLevel"]    value    advanced
    Select Options By    //select[@id="xpathLevel"]    value    advanced

    Uncheck Checkbox    //input[@id="newsletterOptIn"]
    Check Checkbox    //input[@id="hasHobbies"]
    Wait For Elements State    //section[@id="hobbySection"]    visible
    Select Options By    //select[@id="hobbyType_1"]    value    sports
    Type Text    //input[@id="hobbyFrequency_1"]    2 times/week
    Click    //button[@id="addHobbyBtn"]
    Select Options By    //select[@id="hobbyType_2"]    value    music
    Type Text    //input[@id="hobbyFrequency_2"]    5 times/week

    Type Text    //div[./label[text()="Advanced nested field A"]]/input    I found Nested A
    Type Text    //div[./label[text()="Advanced nested field B"]]/input    I found Nested B
    Type Text    //div[./label[text()="Advanced nested field"]]/input    I found Nested C

    ${barwidth}    Get Property    //input[@id="advancedSlider"]    scrollWidth
    Log To Console    ${\n}barwidth=${barwidth}
    ${value}    Set Variable    ${${barwidth} / 10}
    Log To Console    ${\n}barwidth=${barwidth} > value=${value}

    Click With Options    //input[@id="advancedSlider"]    position_x=${{$value * 2}}    position_y=0
    Click With Options    //input[@id="advancedSlider"]    position_x=${{$value * 5}}    position_y=0
    Click With Options    //input[@id="advancedSlider"]    position_x=${{$value * 9}}    position_y=0

    Click    //button[@id="submitBtn"]
    Wait For Elements State    //p[@id="resultMessage" and text()="Form submitted for John!"]    visible
