*** Settings ***
Documentation    Workshop Robot Framework - TC4 External Resource Example

Library      Browser
Resource     tc4_keywords.resource

*** Test Cases ***
Workshop TestCase 4
    [Documentation]    Reusable keyword example with XPath locators extracted to a variables file

    New Browser    browser=chromium    headless=${False}    args=["--ignore-certificate-errors"]
    New Context    ignoreHTTPSErrors=${True}
    New Page    ${URL}
    Form Fill With Variables    name=Emma    email=emma.wyss@swisspost.ch    country=de    years_experience=3    employee_id=DE-007654
    ...                         phone=+49 170 1112233    birth=27.03.1997    contact=email
    ...                         bio=Release validation analyst    motivation=Practice externalized resources
    ...                         address_street=Marktstrasse    address_number=9    address_zip=50667    address_city=Cologne
    ...                         department=finance    shift=night    manager=Thomas Berg    location=Cologne Office
    ...                         browser=chrome    os=macos    rf_experience=beginner    xpath_experience=beginner
    Go To    ${URL}
    Form Fill With Variables    name=Tiago    email=tiago.rocha@swisspost.ch    country=es    years_experience=11    employee_id=ES-003579
    ...                         phone=+34 611 222 333    birth=30.12.1984    contact=phone
    ...                         bio=Senior automation architect    motivation=Demonstrate reusable workshop resources
    ...                         address_street=Paseo de la Castellana    address_number=210    address_zip=28046    address_city=Madrid
    ...                         department=hr    shift=afternoon    manager=Elena Navarro    location=Madrid Campus
    ...                         browser=firefox    os=linux    rf_experience=advanced    xpath_experience=advanced
