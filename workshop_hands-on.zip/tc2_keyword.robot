*** Settings ***
Documentation    Workshop Robot Framework - TC2 Keyword Reuse Example

Library      Browser

*** Variables ***
${URL}    https://carlos-eduardo-1984.github.io/robot_xpath_workshop/


*** Test Cases ***
Workshop TestCase 2
    [Documentation]    Reusable keyword example with multiple datasets

    New Browser    browser=chromium    headless=${False}    args=["--ignore-certificate-errors"]
    New Context    ignoreHTTPSErrors=${True}
    New Page    ${URL}
    Form Fill    John    john@swisspost.ch    pt    4    CH-000999    +41 79 000 00 00    01.01.1972    teams
    ...          Small introduction    Learn    My Street    1     001    The City    operations    night    Jane Doe    The City
    ...          chrome    windows    advanced    advanced
    Go To    ${URL}
    Form Fill    name=Maria    email=maria.silva@swisspost.ch    country=ch    years_experience=7    employee_id=CH-001234
    ...          phone=+41 78 123 45 67    birth=14.05.1988    contact=email
    ...          bio=Automation engineer    motivation=Improve selector skills    address_street=Bahnhofstrasse    address_number=12     address_zip=8001    address_city=Zurich    department=it    shift=morning    manager=Peter Lang    location=Zurich HQ
    ...          browser=edge    os=macos    rf_experience=intermediate    xpath_experience=beginner
    Go To    ${URL}
    Form Fill    name=Luca    email=luca.meier@swisspost.ch    country=de    years_experience=2    employee_id=DE-004321
    ...          phone=+49 151 23456789    birth=22.11.1995    contact=phone
    ...          bio=Junior QA specialist    motivation=Practice Robot Framework forms    address_street=Hauptstrasse    address_number=45     address_zip=10115    address_city=Berlin    department=finance    shift=afternoon    manager=Sabine Koch    location=Berlin Office
    ...          browser=firefox    os=linux    rf_experience=beginner    xpath_experience=intermediate
    Go To    ${URL}
    Form Fill    name=Ines    email=ines.costa@swisspost.ch    country=es    years_experience=10    employee_id=ES-009876
    ...          phone=+34 600 123 456    birth=03.09.1983    contact=teams
    ...          bio=Senior test lead    motivation=Refresh advanced XPath knowledge    address_street=Gran Via    address_number=88     address_zip=28013    address_city=Madrid    department=hr    shift=night    manager=Carlos Ruiz    location=Madrid Hub
    ...          browser=chrome    os=windows    rf_experience=advanced    xpath_experience=advanced


*** Keywords ***
Form Fill
    [Arguments]    ${name}    ${email}    ${country}    ${years_experience}    ${employee_id}
    ...            ${phone}    ${birth}    ${contact}
    ...            ${bio}    ${motivation}
    ...            ${address_street}    ${address_number}    ${address_zip}    ${address_city}
    ...            ${department}    ${shift}    ${manager}    ${location}
    ...            ${browser}    ${os}    ${rf_experience}    ${xpath_experience}

    Type Text    //input[@id="firstName"]    ${name}
    Type Text    //input[@id="emailAddress"]    ${email}
    Select Options By    //select[@id="countrySelect"]    value    ${country}
    Type Text    //input[@id="experienceYears"]    ${years_experience}
    Type Text    //input[@id="employeeId"]    ${employee_id}
    Type Text    //input[@id="phoneNumber"]    ${phone}
    Type Text    //input[@id="birthDate"]    ${birth}
    Select Options By    //select[@id="preferredContact"]    value    ${contact}
    Type Text    //textarea[@id="bioText"]    ${bio}
    Type Text    //textarea[@id="motivationText"]    ${motivation}
    Click    //input[@id="lvlAdvanced"]
    Type Text    //input[@name="street_name"]    ${address_street}
    Type Text    //input[@name="street_number"]    ${address_number}
    Type Text    //input[@name='zip_code']     ${address_zip}
    Type Text    //input[@name='city_name']    ${address_city}
    Select Options By    //select[@name="department"]    value    ${department}
    Select Options By    //select[@name="work_shift"]    value    ${shift}
    Type Text    //input[@name="manager_name"]    ${manager}
    Type Text    //input[@name="office_location"]    ${location}

    Select Options By    //select[@id="mainBrowser"]    value    ${browser}
    Select Options By    //select[@id="osChoice"]    value    ${os}
    Select Options By    //select[@id="robotLevel"]    value    ${rf_experience}
    Select Options By    //select[@id="xpathLevel"]    value    ${xpath_experience}

    Click    //button[@id="submitBtn"]
    Wait For Elements State    //p[@id="resultMessage" and text()="Form submitted for ${name}!"]    visible
